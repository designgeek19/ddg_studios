// One-time helper: renames the brand across the whole project.
//   Full name:    Data & Design Geeks Tech Studio
//   Short name:   DDGTech Studio
//   Abbreviation: DDGs (unchanged)
// Run from the project root:   node tools/apply-rebrand.mjs
// Safe to run twice. It prints what changed in each file. Then run  npm run build,  check the site, commit and push.
import fs from 'node:fs';

const FULL_HTML = 'Data &amp; Design Geeks Tech Studio';   // for HTML text and attributes
const FULL = 'Data & Design Geeks Tech Studio';           // for JSON, JavaScript strings and Markdown
const SHORT = 'DDGTech Studio';
const INSTAGRAM = 'https://www.instagram.com/DDGTech_Studio/';
const OLD_NAME = /Data (?:and|&amp;|&) Design Geeks Studios?/g;

const report = [];
function edit(file, fn) {
  if (!fs.existsSync(file)) return;
  const before = fs.readFileSync(file, 'utf8');
  const after = fn(before);
  if (after !== before) { fs.writeFileSync(file, after); report.push(`UPDATED  ${file}`); }
}

const markup = file => edit(file, s => {
  // 1. JSON-LD blocks use a plain ampersand, not &amp;
  s = s.replace(/(<script type="application\/ld\+json">)([\s\S]*?)(<\/script>)/g, (m, a, body, c) => a + body.replace(OLD_NAME, FULL) + c);
  //    ...and so do the JavaScript objects in the case-study page generator that become JSON-LD
  s = s.replace(/name: 'Data (?:and|&) Design Geeks Studios?'/g, `name: '${FULL}'`);
  // 2. Header and footer wordmark: DDG + Studio  ->  DDGTech + Studio (&nbsp; keeps the space in flex layouts)
  s = s.replace(/DDG(?:Tech(?:&nbsp;| )?)?(<span class="text-brand-500 dark:text-emerald-400">Studio<\/span>)/g, 'DDGTech&nbsp;$1');
  // 3. Full name everywhere else in the page text
  s = s.replace(OLD_NAME, FULL_HTML);
  // 4. Short name in running text
  s = s.replace(/\bDDG Studio\b(?!s)/g, SHORT);
  // 5. Home page structured data: short name too, plus the Instagram profile
  s = s.replace('"alternateName": "DDGs",', `"alternateName": ["${SHORT}", "DDGs"],`);
  if (s.includes('"sameAs": [') && !s.includes('instagram.com/DDGTech_Studio')) {
    s = s.replace(/("https:\/\/www\.facebook\.com\/people\/Data-Design-Geeks\/100063655043554\/")(\s*\])/, `$1,\n    "${INSTAGRAM}"$2`);
  }
  // 6. Footer link to Instagram, placed before the Behance link
  if (/<li><a href="https:\/\/www\.behance/.test(s) && !s.includes('>Instagram</a>')) {
    s = s.replace(/<li><a href="https:\/\/www\.behance\.net\/DesignGeeksStudio"([^>]*)>Behance<\/a><\/li>/, (m, attrs) => `<li><a href="${INSTAGRAM}"${attrs}>Instagram</a></li>${m}`);
  }
  return s;
});
const plain = file => edit(file, s => s.replace(OLD_NAME, FULL));

const root = fs.readdirSync('.').filter(f => f.endsWith('.html'));
const cases = fs.existsSync('case-studies') ? fs.readdirSync('case-studies').filter(f => f.endsWith('.html')).map(f => `case-studies/${f}`) : [];
[...root, ...cases, 'tools/build-case-studies.mjs'].forEach(markup);

edit('privacy.html', s => s
  .replace('(&ldquo;DDGs&rdquo;,', `(&ldquo;${SHORT}&rdquo;, &ldquo;DDGs&rdquo;,`)
  .replace(/Last updated: [A-Za-z]+ \d{1,2}, \d{4}/, 'Last updated: November 3, 2026'));
['README.md', 'CASE-STUDIES.md', 'FORM-SETUP.md', 'package.json'].forEach(plain);
edit('README.md', s => s.replace(/^# DDG-STUDIOS/m, `# ${SHORT}`));

const left = [];
for (const f of [...root, ...cases, 'tools/build-case-studies.mjs', 'README.md', 'package.json']) {
  if (!fs.existsSync(f)) continue;
  const s = fs.readFileSync(f, 'utf8');
  if (new RegExp(OLD_NAME.source).test(s) || /DDG<span/.test(s) || /DDGTech <span/.test(s)) left.push(f);
}
console.log('\n' + (report.join('\n') || 'Nothing to change (already done).'));
console.log(left.length ? `\nCHECK BY HAND: old name still found in: ${left.join(', ')}` : '\nNo old brand name left in pages, generator, README or package.json.');
console.log('\nNext: run  npm run build,  open the site, then commit and push.');
